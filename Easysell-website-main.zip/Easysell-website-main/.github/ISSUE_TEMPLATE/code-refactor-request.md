---
name: Code refactor request
about: Suggest code improvements
title: ''
labels: ''
assignees: ''

---

**Describe the code quality issue.**
A clear and concise description of the current problem in the code.

**Expected Improvements**
How can the above problem be fixed?

**Additional Context**
Add screenshots or further context.
